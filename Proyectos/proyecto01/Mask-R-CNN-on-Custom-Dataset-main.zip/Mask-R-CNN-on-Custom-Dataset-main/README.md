# Mask-R-CNN-on-Custom-Dataset

Create folder :  Dataset

In Dataset folder create 2 folders : train and val
Put training images in train folder and validation images in Val folder.

Download mrcnn folder from this repository: https://github.com/matterport/Mask_RCNN

Download coco weights :  https://github.com/matterport/Mask_RCNN/releases/download/v2.0/mask_rcnn_coco.h5

Follow this video to understand the whole working:  https://youtu.be/1u-dm5JMH1Q





